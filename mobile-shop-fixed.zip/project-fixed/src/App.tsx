import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import AdminLayout from './components/AdminLayout';
import Home from './pages/Home';
import Phones from './pages/Phones';
import Accessories from './pages/Accessories';
import Offers from './pages/Offers';
import Repair from './pages/Repair';
import About from './pages/About';
import Contact from './pages/Contact';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import ProductDetail from './pages/ProductDetail';
import AdminLogin from './pages/AdminLogin';
import FirstSetup from './pages/FirstSetup';
import AdminDashboard from './pages/AdminDashboard';
import AdminProducts from './pages/AdminProducts';
import AdminCompanies from './pages/AdminCompanies';
import AdminCategories from './pages/AdminCategories';
import AdminBanners from './pages/AdminBanners';
import AdminOffers from './pages/AdminOffers';
import AdminRepairs from './pages/AdminRepairs';
import AdminReviews from './pages/AdminReviews';
import AdminSettings from './pages/AdminSettings';
import AdminUsers from './pages/AdminUsers';
import AdminBackup from './pages/AdminBackup';
import NotFound from './pages/NotFound';
import { db } from './lib/db';
import { isFirstRun } from './lib/auth';

function AdminRoute({ children }: { children: React.ReactNode }) {
  return db.auth.isAuthenticated() ? <>{children}</> : <Navigate to="/admin-login" replace />;
}

function FirstSetupRoute({ children }: { children: React.ReactNode }) {
  return isFirstRun() ? <>{children}</> : <Navigate to="/admin-login" replace />;
}

function LoginRoute({ children }: { children: React.ReactNode }) {
  if (db.auth.isAuthenticated()) return <Navigate to="/admin" replace />;
  if (isFirstRun()) return <Navigate to="/first-setup" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <HashRouter>
      <Routes>
        {/* Public Routes */}
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/phones" element={<Phones />} />
          <Route path="/accessories" element={<Accessories />} />
          <Route path="/offers" element={<Offers />} />
          <Route path="/repair" element={<Repair />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/product/:id" element={<ProductDetail />} />
        </Route>

        {/* First Setup - Only shows once */}
        <Route path="/first-setup" element={<FirstSetupRoute><FirstSetup /></FirstSetupRoute>} />

        {/* Admin Login */}
        <Route path="/admin-login" element={<LoginRoute><AdminLogin /></LoginRoute>} />

        {/* Admin Routes - Protected */}
        <Route path="/admin" element={<AdminRoute><AdminLayout /></AdminRoute>}>
          <Route index element={<AdminDashboard />} />
          <Route path="products" element={<AdminProducts />} />
          <Route path="companies" element={<AdminCompanies />} />
          <Route path="categories" element={<AdminCategories />} />
          <Route path="banners" element={<AdminBanners />} />
          <Route path="offers" element={<AdminOffers />} />
          <Route path="repairs" element={<AdminRepairs />} />
          <Route path="reviews" element={<AdminReviews />} />
          <Route path="settings" element={<AdminSettings />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="backup" element={<AdminBackup />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </HashRouter>
  );
}
