import { db } from './db';

// ========================================================
// تشفير قوي باستخدام Web Crypto API (SHA-256 + Salt)
// ========================================================

async function hashPassword(password: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(salt + password + salt);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function generateSalt(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('');
}

// ========================================================
// واجهة تخزين الباسوردات
// ========================================================

interface StoredPassword {
  hash: string;
  salt: string;
}

function getPasswords(): Record<string, StoredPassword> {
  try {
    return JSON.parse(localStorage.getItem('mobily_pro_passwords') || '{}');
  } catch {
    return {};
  }
}

function savePasswords(passwords: Record<string, StoredPassword>): void {
  localStorage.setItem('mobily_pro_passwords', JSON.stringify(passwords));
}

// ========================================================
// الدوال المُصدَّرة
// ========================================================

export function isFirstRun(): boolean {
  const users = db.users.getAll();
  return users.length === 0;
}

export async function createSuperAdmin(
  email: string,
  password: string,
  name: string
): Promise<boolean> {
  if (!isFirstRun()) return false;

  const salt = generateSalt();
  const hash = await hashPassword(password, salt);

  db.users.create({
    email,
    name,
    role: 'super_admin',
  });

  const passwords = getPasswords();
  passwords[email] = { hash, salt };
  savePasswords(passwords);

  return true;
}

export async function loginUser(
  email: string,
  password: string
): Promise<ReturnType<typeof db.auth.login>> {
  const passwords = getPasswords();
  const stored = passwords[email];

  if (!stored) return null;

  const hash = await hashPassword(password, stored.salt);
  if (hash !== stored.hash) return null;

  return db.auth.login(email);
}

export async function changePassword(
  email: string,
  newPassword: string
): Promise<boolean> {
  const salt = generateSalt();
  const hash = await hashPassword(newPassword, salt);
  const passwords = getPasswords();
  passwords[email] = { hash, salt };
  savePasswords(passwords);
  return true;
}

export async function verifyPassword(
  password: string,
  email: string
): Promise<boolean> {
  const passwords = getPasswords();
  const stored = passwords[email];
  if (!stored) return false;
  const hash = await hashPassword(password, stored.salt);
  return hash === stored.hash;
}
