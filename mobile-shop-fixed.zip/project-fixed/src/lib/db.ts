import type { Product, Company, Category, Banner, RepairRequest, Review, SiteSettings, AdminUser } from '../types';

const STORAGE_KEYS = {
  products: 'mobily_pro_products',
  companies: 'mobily_pro_companies',
  categories: 'mobily_pro_categories',
  banners: 'mobily_pro_banners',
  repairs: 'mobily_pro_repairs',
  reviews: 'mobily_pro_reviews',
  settings: 'mobily_pro_settings',
  users: 'mobily_pro_users',
  auth: 'mobily_pro_auth',
};

function getItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Initialize default data
function initDefaults() {
  if (!localStorage.getItem(STORAGE_KEYS.settings)) {
    const defaultSettings: SiteSettings = {
      id: '1',
      siteName: 'موبايلي برو',
      whatsappNumber: '',
      phoneNumber: '',
      email: '',
      address: 'مصر',
      facebook: '',
      instagram: '',
      workingHours: {
        saturday: '10:00 ص - 10:00 م',
        sunday: '10:00 ص - 10:00 م',
        monday: '10:00 ص - 10:00 م',
        tuesday: '10:00 ص - 10:00 م',
        wednesday: '10:00 ص - 10:00 م',
        thursday: '10:00 ص - 10:00 م',
        friday: '2:00 م - 10:00 م',
      },
      aboutText: 'موبايلي برو هو وجهتك الأولى لشراء الهواتف الجديدة والمستعملة وإكسسوارات الهواتف وخدمات الصيانة. نقدم منتجات أصلية بجودة عالية وأسعار تنافسية مع ضمان على جميع منتجاتنا.',
      privacyText: 'نحن نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية. لا نشارك معلوماتك مع أي طرف ثالث.',
      termsText: 'باستخدامك لهذا الموقع، فإنك توافق على الشروط والأحكام الخاصة بنا. جميع المنتجات خاضعة لسياسة الإرجاع خلال 14 يوماً.',
    };
    setItem(STORAGE_KEYS.settings, defaultSettings);
  }

  // لا يوجد مستخدم افتراضي — يُنشأ عبر صفحة الإعداد الأول /first-setup

  if (!localStorage.getItem(STORAGE_KEYS.companies)) {
    const defaultCompanies: Company[] = [
      { id: '1', name: 'Samsung', type: 'phone', createdAt: new Date().toISOString() },
      { id: '2', name: 'Apple', type: 'phone', createdAt: new Date().toISOString() },
      { id: '3', name: 'Xiaomi', type: 'phone', createdAt: new Date().toISOString() },
      { id: '4', name: 'Oppo', type: 'phone', createdAt: new Date().toISOString() },
      { id: '5', name: 'Realme', type: 'phone', createdAt: new Date().toISOString() },
      { id: '6', name: 'Huawei', type: 'phone', createdAt: new Date().toISOString() },
      { id: '7', name: 'Vivo', type: 'phone', createdAt: new Date().toISOString() },
      { id: '8', name: 'Infinix', type: 'phone', createdAt: new Date().toISOString() },
      { id: '9', name: 'Tecno', type: 'phone', createdAt: new Date().toISOString() },
      { id: '10', name: 'Nokia', type: 'phone', createdAt: new Date().toISOString() },
    ];
    setItem(STORAGE_KEYS.companies, defaultCompanies);
  }

  if (!localStorage.getItem(STORAGE_KEYS.categories)) {
    const defaultCategories: Category[] = [
      { id: '1', name: 'سماعات', type: 'accessory', createdAt: new Date().toISOString() },
      { id: '2', name: 'جرابات', type: 'accessory', createdAt: new Date().toISOString() },
      { id: '3', name: 'اسكرينات حماية', type: 'accessory', createdAt: new Date().toISOString() },
      { id: '4', name: 'شواحن', type: 'accessory', createdAt: new Date().toISOString() },
      { id: '5', name: 'كابلات', type: 'accessory', createdAt: new Date().toISOString() },
      { id: '6', name: 'باور بانك', type: 'accessory', createdAt: new Date().toISOString() },
      { id: '7', name: 'ساعات ذكية', type: 'accessory', createdAt: new Date().toISOString() },
      { id: '8', name: 'حاملات هواتف', type: 'accessory', createdAt: new Date().toISOString() },
    ];
    setItem(STORAGE_KEYS.categories, defaultCategories);
  }

  if (!localStorage.getItem(STORAGE_KEYS.banners)) {
    const defaultBanners: Banner[] = [
      {
        id: '1',
        title: 'أحدث الهواتف الذكية',
        subtitle: 'اكتشف مجموعتنا الواسعة من الهواتف الجديدة والمستعملة',
        image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=1200&h=500&fit=crop',
        link: '/phones',
        isActive: true,
        order: 1,
      },
      {
        id: '2',
        title: 'إكسسوارات متميزة',
        subtitle: 'جميع ما تحتاجه لهاتفك من إكسسوارات عالية الجودة',
        image: 'https://images.unsplash.com/photo-1586816879360-004f5b0c51e3?w=1200&h=500&fit=crop',
        link: '/accessories',
        isActive: true,
        order: 2,
      },
      {
        id: '3',
        title: 'خدمات الصيانة',
        subtitle: 'فريق متخصص لصيانة جميع أنواع الهواتف',
        image: 'https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=1200&h=500&fit=crop',
        link: '/repair',
        isActive: true,
        order: 3,
      },
    ];
    setItem(STORAGE_KEYS.banners, defaultBanners);
  }

  if (!localStorage.getItem(STORAGE_KEYS.reviews)) {
    const defaultReviews: Review[] = [
      {
        id: '1',
        name: 'أحمد محمد',
        rating: 5,
        comment: 'تجربة رائعة! الهاتف وصل بحالة ممتازة والسعر كان أفضل من السوق. أنصح الجميع بالتعامل مع موبايلي برو.',
        isActive: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        name: 'سارة علي',
        rating: 5,
        comment: 'خدمة الصيانة سريعة ومحترفة. حلول المشكلة في نفس اليوم. شكراً لفريق العمل الرائع.',
        isActive: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: '3',
        name: 'محمد عبدالله',
        rating: 4,
        comment: 'تشكيلة الإكسسوارات واسعة والأسعار منافسة. سأكون عميل دائم بإذن الله.',
        isActive: true,
        createdAt: new Date().toISOString(),
      },
    ];
    setItem(STORAGE_KEYS.reviews, defaultReviews);
  }

  // Add sample products
  if (!localStorage.getItem(STORAGE_KEYS.products)) {
    const sampleProducts: Product[] = [
      {
        id: '1',
        name: 'iPhone 15 Pro Max',
        description: 'أحدث هواتف آبل مع معالج A17 Pro وشاشة Super Retina XDR',
        images: ['https://images.unsplash.com/photo-1696446701796-da61225697cc?w=600&h=600&fit=crop'],
        category: 'phone_new',
        company: 'Apple',
        model: 'iPhone 15 Pro Max',
        isOffer: true,
        isHidden: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        name: 'Samsung Galaxy S24 Ultra',
        description: 'هاتف سامسونج الرائد مع قلم S Pen وكاميرا 200 ميجابكسل',
        images: ['https://images.unsplash.com/photo-1610945265078-3858a0828671?w=600&h=600&fit=crop'],
        category: 'phone_new',
        company: 'Samsung',
        model: 'Galaxy S24 Ultra',
        isOffer: false,
        isHidden: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: '3',
        name: 'iPhone 13 Pro',
        description: 'هاتف أيفون 13 برو بحالة ممتازة، بطارية 92%',
        images: ['https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=600&h=600&fit=crop'],
        category: 'phone_used',
        company: 'Apple',
        model: 'iPhone 13 Pro',
        ram: '6 GB',
        storage: '256 GB',
        batteryHealth: 92,
        condition: 'excellent',
        hasCharger: true,
        conditionNotes: 'الجهاز بحالة ممتازة، لا يوجد خدوش، مع شاحن أصلي وعلبة',
        isOffer: true,
        isHidden: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: '4',
        name: 'سماعات AirPods Pro 2',
        description: 'سماعات آبل اللاسلكية مع خاصية إلغاء الضوضاء النشطة',
        images: ['https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=600&h=600&fit=crop'],
        category: 'accessory',
        accessoryType: 'سماعات',
        isOffer: false,
        isHidden: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: '5',
        name: 'شاحن سريع 65W',
        description: 'شاحن سريع متعدد المنافذ يدعم جميع الأجهزة',
        images: ['https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=600&h=600&fit=crop'],
        category: 'accessory',
        accessoryType: 'شواحن',
        isOffer: true,
        isHidden: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: '6',
        name: 'Xiaomi Redmi Note 13',
        description: 'هاتف شاومي الجديد بكاميرا 108 ميجابكسل وبطارية 5000mAh',
        images: ['https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=600&h=600&fit=crop'],
        category: 'phone_new',
        company: 'Xiaomi',
        model: 'Redmi Note 13',
        isOffer: true,
        isHidden: false,
        createdAt: new Date().toISOString(),
      },
    ];
    setItem(STORAGE_KEYS.products, sampleProducts);
  }
}

initDefaults();

export const db = {
  products: {
    getAll: (): Product[] => getItem<Product[]>(STORAGE_KEYS.products, []),
    getById: (id: string): Product | undefined => db.products.getAll().find(p => p.id === id),
    getByCategory: (category: string): Product[] => db.products.getAll().filter(p => p.category === category && !p.isHidden),
    getOffers: (): Product[] => db.products.getAll().filter(p => p.isOffer && !p.isHidden),
    getLatest: (limit: number = 6): Product[] => db.products.getAll()
      .filter(p => !p.isHidden)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit),
    create: (product: Omit<Product, 'id' | 'createdAt'>): Product => {
      const products = db.products.getAll();
      const newProduct: Product = { ...product, id: generateId(), createdAt: new Date().toISOString() };
      setItem(STORAGE_KEYS.products, [...products, newProduct]);
      return newProduct;
    },
    update: (id: string, updates: Partial<Product>): Product | null => {
      const products = db.products.getAll();
      const index = products.findIndex(p => p.id === id);
      if (index === -1) return null;
      products[index] = { ...products[index], ...updates };
      setItem(STORAGE_KEYS.products, products);
      return products[index];
    },
    delete: (id: string): boolean => {
      const products = db.products.getAll();
      const filtered = products.filter(p => p.id !== id);
      if (filtered.length === products.length) return false;
      setItem(STORAGE_KEYS.products, filtered);
      return true;
    },
  },

  companies: {
    getAll: (): Company[] => getItem<Company[]>(STORAGE_KEYS.companies, []),
    getByType: (type: string): Company[] => db.companies.getAll().filter(c => c.type === type),
    create: (company: Omit<Company, 'id' | 'createdAt'>): Company => {
      const companies = db.companies.getAll();
      const newCompany: Company = { ...company, id: generateId(), createdAt: new Date().toISOString() };
      setItem(STORAGE_KEYS.companies, [...companies, newCompany]);
      return newCompany;
    },
    update: (id: string, updates: Partial<Company>): Company | null => {
      const companies = db.companies.getAll();
      const index = companies.findIndex(c => c.id === id);
      if (index === -1) return null;
      companies[index] = { ...companies[index], ...updates };
      setItem(STORAGE_KEYS.companies, companies);
      return companies[index];
    },
    delete: (id: string): boolean => {
      const companies = db.companies.getAll();
      const filtered = companies.filter(c => c.id !== id);
      if (filtered.length === companies.length) return false;
      setItem(STORAGE_KEYS.companies, filtered);
      return true;
    },
  },

  categories: {
    getAll: (): Category[] => getItem<Category[]>(STORAGE_KEYS.categories, []),
    getByType: (type: string): Category[] => db.categories.getAll().filter(c => c.type === type),
    create: (category: Omit<Category, 'id' | 'createdAt'>): Category => {
      const categories = db.categories.getAll();
      const newCategory: Category = { ...category, id: generateId(), createdAt: new Date().toISOString() };
      setItem(STORAGE_KEYS.categories, [...categories, newCategory]);
      return newCategory;
    },
    update: (id: string, updates: Partial<Category>): Category | null => {
      const categories = db.categories.getAll();
      const index = categories.findIndex(c => c.id === id);
      if (index === -1) return null;
      categories[index] = { ...categories[index], ...updates };
      setItem(STORAGE_KEYS.categories, categories);
      return categories[index];
    },
    delete: (id: string): boolean => {
      const categories = db.categories.getAll();
      const filtered = categories.filter(c => c.id !== id);
      if (filtered.length === categories.length) return false;
      setItem(STORAGE_KEYS.categories, filtered);
      return true;
    },
  },

  banners: {
    getAll: (): Banner[] => getItem<Banner[]>(STORAGE_KEYS.banners, []),
    getActive: (): Banner[] => db.banners.getAll().filter(b => b.isActive).sort((a, b) => a.order - b.order),
    create: (banner: Omit<Banner, 'id'>): Banner => {
      const banners = db.banners.getAll();
      const newBanner: Banner = { ...banner, id: generateId() };
      setItem(STORAGE_KEYS.banners, [...banners, newBanner]);
      return newBanner;
    },
    update: (id: string, updates: Partial<Banner>): Banner | null => {
      const banners = db.banners.getAll();
      const index = banners.findIndex(b => b.id === id);
      if (index === -1) return null;
      banners[index] = { ...banners[index], ...updates };
      setItem(STORAGE_KEYS.banners, banners);
      return banners[index];
    },
    delete: (id: string): boolean => {
      const banners = db.banners.getAll();
      const filtered = banners.filter(b => b.id !== id);
      if (filtered.length === banners.length) return false;
      setItem(STORAGE_KEYS.banners, filtered);
      return true;
    },
  },

  repairs: {
    getAll: (): RepairRequest[] => getItem<RepairRequest[]>(STORAGE_KEYS.repairs, []),
    create: (repair: Omit<RepairRequest, 'id' | 'createdAt' | 'status'>): RepairRequest => {
      const repairs = db.repairs.getAll();
      const newRepair: RepairRequest = {
        ...repair,
        id: generateId(),
        status: 'pending',
        createdAt: new Date().toISOString(),
      };
      setItem(STORAGE_KEYS.repairs, [...repairs, newRepair]);
      return newRepair;
    },
    update: (id: string, updates: Partial<RepairRequest>): RepairRequest | null => {
      const repairs = db.repairs.getAll();
      const index = repairs.findIndex(r => r.id === id);
      if (index === -1) return null;
      repairs[index] = { ...repairs[index], ...updates };
      setItem(STORAGE_KEYS.repairs, repairs);
      return repairs[index];
    },
    delete: (id: string): boolean => {
      const repairs = db.repairs.getAll();
      const filtered = repairs.filter(r => r.id !== id);
      if (filtered.length === repairs.length) return false;
      setItem(STORAGE_KEYS.repairs, filtered);
      return true;
    },
  },

  reviews: {
    getAll: (): Review[] => getItem<Review[]>(STORAGE_KEYS.reviews, []),
    getActive: (): Review[] => db.reviews.getAll().filter(r => r.isActive),
    create: (review: Omit<Review, 'id' | 'createdAt'>): Review => {
      const reviews = db.reviews.getAll();
      const newReview: Review = { ...review, id: generateId(), createdAt: new Date().toISOString() };
      setItem(STORAGE_KEYS.reviews, [...reviews, newReview]);
      return newReview;
    },
    update: (id: string, updates: Partial<Review>): Review | null => {
      const reviews = db.reviews.getAll();
      const index = reviews.findIndex(r => r.id === id);
      if (index === -1) return null;
      reviews[index] = { ...reviews[index], ...updates };
      setItem(STORAGE_KEYS.reviews, reviews);
      return reviews[index];
    },
    delete: (id: string): boolean => {
      const reviews = db.reviews.getAll();
      const filtered = reviews.filter(r => r.id !== id);
      if (filtered.length === reviews.length) return false;
      setItem(STORAGE_KEYS.reviews, filtered);
      return true;
    },
  },

  settings: {
    get: (): SiteSettings => getItem<SiteSettings>(STORAGE_KEYS.settings, {} as SiteSettings),
    update: (updates: Partial<SiteSettings>): SiteSettings => {
      const settings = db.settings.get();
      const updated = { ...settings, ...updates };
      setItem(STORAGE_KEYS.settings, updated);
      return updated;
    },
  },

  users: {
    getAll: (): AdminUser[] => getItem<AdminUser[]>(STORAGE_KEYS.users, []),
    getByEmail: (email: string): AdminUser | undefined => db.users.getAll().find(u => u.email === email),
    create: (user: Omit<AdminUser, 'id' | 'createdAt'>): AdminUser => {
      const users = db.users.getAll();
      const newUser: AdminUser = { ...user, id: generateId(), createdAt: new Date().toISOString() };
      setItem(STORAGE_KEYS.users, [...users, newUser]);
      return newUser;
    },
    update: (id: string, updates: Partial<AdminUser>): AdminUser | null => {
      const users = db.users.getAll();
      const index = users.findIndex(u => u.id === id);
      if (index === -1) return null;
      users[index] = { ...users[index], ...updates };
      setItem(STORAGE_KEYS.users, users);
      return users[index];
    },
    delete: (id: string): boolean => {
      const users = db.users.getAll();
      const filtered = users.filter(u => u.id !== id);
      if (filtered.length === users.length) return false;
      setItem(STORAGE_KEYS.users, filtered);
      return true;
    },
  },

  auth: {
    // يُستدعى فقط بعد التحقق من الباسورد في auth.ts
    login: (email: string): AdminUser | null => {
      const user = db.users.getByEmail(email);
      if (user) {
        setItem(STORAGE_KEYS.auth, { user, token: generateId() });
        return user;
      }
      return null;
    },
    logout: (): void => {
      localStorage.removeItem(STORAGE_KEYS.auth);
    },
    getCurrentUser: (): AdminUser | null => {
      const auth = getItem<{ user: AdminUser; token: string } | null>(STORAGE_KEYS.auth, null);
      return auth?.user || null;
    },
    isAuthenticated: (): boolean => !!db.auth.getCurrentUser(),
    isSuperAdmin: (): boolean => db.auth.getCurrentUser()?.role === 'super_admin',
  },
};

export default db;
