import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Search, Eye, EyeOff } from 'lucide-react';
import { db } from '../lib/db';
import type { Product } from '../types';

const emptyProduct: Omit<Product, 'id' | 'createdAt'> = {
  name: '',
  description: '',
  images: [],
  category: 'phone_new',
  company: '',
  model: '',
  ram: '',
  storage: '',
  batteryHealth: undefined,
  condition: undefined,
  hasCharger: false,
  conditionNotes: '',
  accessoryType: '',
  isOffer: false,
  isHidden: false,
};

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyProduct);
  const [imageUrl, setImageUrl] = useState('');

  const loadProducts = () => {
    setProducts(db.products.getAll().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.company?.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setForm(emptyProduct);
    setEditingId(null);
    setImageUrl('');
    setShowModal(true);
  };

  const openEdit = (product: Product) => {
    setForm({
      name: product.name,
      description: product.description,
      images: [...product.images],
      category: product.category,
      company: product.company || '',
      model: product.model || '',
      ram: product.ram || '',
      storage: product.storage || '',
      batteryHealth: product.batteryHealth,
      condition: product.condition,
      hasCharger: product.hasCharger || false,
      conditionNotes: product.conditionNotes || '',
      accessoryType: product.accessoryType || '',
      isOffer: product.isOffer,
      isHidden: product.isHidden,
    });
    setEditingId(product.id);
    setImageUrl('');
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      db.products.update(editingId, form);
    } else {
      db.products.create(form);
    }
    setShowModal(false);
    loadProducts();
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      db.products.delete(id);
      loadProducts();
    }
  };

  const addImage = () => {
    if (imageUrl.trim()) {
      setForm(prev => ({ ...prev, images: [...prev.images, imageUrl.trim()] }));
      setImageUrl('');
    }
  };

  const removeImage = (index: number) => {
    setForm(prev => ({ ...prev, images: prev.images.filter((_, i) => i !== index) }));
  };

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'phone_new': return 'هاتف جديد';
      case 'phone_used': return 'هاتف مستعمل';
      case 'accessory': return 'إكسسوار';
      default: return cat;
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">المنتجات</h1>
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-4 py-2 rounded-lg transition-colors"
        >
          <Plus className="w-5 h-5" />
          إضافة منتج
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100">
        <div className="p-4 border-b border-slate-100">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="البحث في المنتجات..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-10 pl-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-700">المنتج</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-700">النوع</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-700">الشركة</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-700">الحالة</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-700">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((product) => (
                <tr key={product.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <img src={product.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover bg-slate-100" />
                      <span className="font-medium text-slate-900">{product.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-slate-600">{getCategoryLabel(product.category)}</td>
                  <td className="px-4 py-3 text-sm text-slate-600">{product.company || '-'}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {product.isOffer && <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded">عرض</span>}
                      {product.isHidden ? (
                        <span className="text-xs bg-slate-100 text-slate-500 px-2 py-0.5 rounded flex items-center gap-1">
                          <EyeOff className="w-3 h-3" /> مخفي
                        </span>
                      ) : (
                        <span className="text-xs bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded flex items-center gap-1">
                          <Eye className="w-3 h-3" /> ظاهر
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openEdit(product)}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(product.id)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            لا توجد منتجات
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-100 sticky top-0 bg-white">
              <h2 className="text-lg font-bold">{editingId ? 'تعديل منتج' : 'إضافة منتج'}</h2>
              <button onClick={() => setShowModal(false)} className="p-1 hover:bg-slate-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">نوع المنتج *</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm(prev => ({ ...prev, category: e.target.value as any }))}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="phone_new">هاتف جديد</option>
                  <option value="phone_used">هاتف مستعمل</option>
                  <option value="accessory">إكسسوار</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">اسم المنتج *</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">الوصف</label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                />
              </div>

              {/* Dynamic fields based on category */}
              {(form.category === 'phone_new' || form.category === 'phone_used') && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">الشركة</label>
                      <input
                        type="text"
                        value={form.company}
                        onChange={(e) => setForm(prev => ({ ...prev, company: e.target.value }))}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                        placeholder="Samsung, Apple..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">الموديل</label>
                      <input
                        type="text"
                        value={form.model}
                        onChange={(e) => setForm(prev => ({ ...prev, model: e.target.value }))}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>
                </>
              )}

              {form.category === 'phone_used' && (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">الرام</label>
                      <input
                        type="text"
                        value={form.ram}
                        onChange={(e) => setForm(prev => ({ ...prev, ram: e.target.value }))}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                        placeholder="8 GB"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">المساحة</label>
                      <input
                        type="text"
                        value={form.storage}
                        onChange={(e) => setForm(prev => ({ ...prev, storage: e.target.value }))}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                        placeholder="256 GB"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">صحة البطارية %</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={form.batteryHealth || ''}
                        onChange={(e) => setForm(prev => ({ ...prev, batteryHealth: e.target.value ? Number(e.target.value) : undefined }))}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">حالة الجهاز</label>
                      <select
                        value={form.condition || ''}
                        onChange={(e) => setForm(prev => ({ ...prev, condition: e.target.value as any || undefined }))}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                      >
                        <option value="">اختر الحالة</option>
                        <option value="excellent">ممتازة</option>
                        <option value="very_good">جيدة جداً</option>
                        <option value="good">جيدة</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-2 pt-6">
                      <input
                        type="checkbox"
                        id="hasCharger"
                        checked={form.hasCharger}
                        onChange={(e) => setForm(prev => ({ ...prev, hasCharger: e.target.checked }))}
                        className="w-4 h-4 text-emerald-500 rounded"
                      />
                      <label htmlFor="hasCharger" className="text-sm text-slate-700">مرفق بشاحن</label>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">ملاحظات الحالة</label>
                    <textarea
                      rows={2}
                      value={form.conditionNotes}
                      onChange={(e) => setForm(prev => ({ ...prev, conditionNotes: e.target.value }))}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                    />
                  </div>
                </>
              )}

              {form.category === 'accessory' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">نوع الإكسسوار</label>
                  <input
                    type="text"
                    value={form.accessoryType}
                    onChange={(e) => setForm(prev => ({ ...prev, accessoryType: e.target.value }))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                    placeholder="سماعات، جراب، شاحن..."
                  />
                </div>
              )}

              {/* Images */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">الصور</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="رابط الصورة"
                    className="flex-1 px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                  <button
                    type="button"
                    onClick={addImage}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-sm font-medium transition-colors"
                  >
                    إضافة
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {form.images.map((img, idx) => (
                    <div key={idx} className="relative w-20 h-20 rounded-lg overflow-hidden bg-slate-100">
                      <img src={img} alt="" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => removeImage(idx)}
                        className="absolute top-0.5 left-0.5 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Options */}
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={form.isOffer}
                    onChange={(e) => setForm(prev => ({ ...prev, isOffer: e.target.checked }))}
                    className="w-4 h-4 text-emerald-500 rounded"
                  />
                  <span className="text-sm text-slate-700">عرض خاص</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={form.isHidden}
                    onChange={(e) => setForm(prev => ({ ...prev, isHidden: e.target.checked }))}
                    className="w-4 h-4 text-emerald-500 rounded"
                  />
                  <span className="text-sm text-slate-700">إخفاء المنتج</span>
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition-colors"
                >
                  {editingId ? 'حفظ التعديلات' : 'إضافة منتج'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
