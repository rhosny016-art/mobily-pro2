import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package, ChevronLeft } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import ProductCard from '../components/ProductCard';
import { db } from '../lib/db';
import type { Product, Category } from '../types';

export default function Accessories() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    setCategories(db.categories.getByType('accessory'));
  }, []);

  useEffect(() => {
    let filtered = db.products.getByCategory('accessory');
    if (selectedCategory) {
      filtered = filtered.filter(p => p.accessoryType === selectedCategory);
    }
    setProducts(filtered);
  }, [selectedCategory]);

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="الإكسسوارات" subtitle="جميع ما تحتاجه لهاتفك من إكسسوارات عالية الجودة" />

      {/* Categories */}
      <div className="mb-8">
        <div className="flex flex-wrap justify-center gap-2">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              selectedCategory === null
                ? 'bg-slate-900 text-white'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            الكل
          </button>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.name)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedCategory === category.name
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      {products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 text-lg">لا توجد إكسسوارات في هذا القسم حالياً</p>
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium mt-4"
          >
            <ChevronLeft className="w-4 h-4" />
            العودة للرئيسية
          </Link>
        </div>
      )}
    </div>
  );
}
