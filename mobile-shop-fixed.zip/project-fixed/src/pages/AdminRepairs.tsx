import { useState, useEffect } from 'react';
import { Wrench, CheckCircle, XCircle, Clock } from 'lucide-react';
import { db } from '../lib/db';
import type { RepairRequest } from '../types';

const statusLabels: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: 'قيد الانتظار', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
  in_progress: { label: 'قيد التنفيذ', color: 'bg-blue-100 text-blue-700', icon: Wrench },
  completed: { label: 'مكتمل', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle },
  cancelled: { label: 'ملغي', color: 'bg-red-100 text-red-700', icon: XCircle },
};

export default function AdminRepairs() {
  const [repairs, setRepairs] = useState<RepairRequest[]>([]);

  const load = () => setRepairs(db.repairs.getAll().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  useEffect(() => { load(); }, []);

  const updateStatus = (id: string, status: RepairRequest['status']) => {
    db.repairs.update(id, { status });
    load();
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-6">طلبات الصيانة</h1>
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-semibold">العميل</th>
                <th className="px-4 py-3 text-right text-sm font-semibold">الجهاز</th>
                <th className="px-4 py-3 text-right text-sm font-semibold">المشكلة</th>
                <th className="px-4 py-3 text-right text-sm font-semibold">الحالة</th>
                <th className="px-4 py-3 text-right text-sm font-semibold">التاريخ</th>
                <th className="px-4 py-3 text-right text-sm font-semibold">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {repairs.map(repair => {
                const status = statusLabels[repair.status];
                const StatusIcon = status.icon;
                return (
                  <tr key={repair.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <p className="font-medium text-slate-900">{repair.fullName}</p>
                      <p className="text-sm text-slate-500" dir="ltr">{repair.phone}</p>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <p>{repair.company} {repair.model}</p>
                      <p className="text-slate-500">{repair.deviceType}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600 max-w-xs truncate">{repair.problemDescription}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded ${status.color}`}>
                        <StatusIcon className="w-3 h-3" /> {status.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-500">
                      {new Date(repair.createdAt).toLocaleDateString('ar-EG')}
                    </td>
                    <td className="px-4 py-3">
                      <select
                        value={repair.status}
                        onChange={e => updateStatus(repair.id, e.target.value as RepairRequest['status'])}
                        className="text-sm border border-slate-200 rounded-lg px-2 py-1 focus:ring-2 focus:ring-emerald-500 outline-none"
                      >
                        <option value="pending">قيد الانتظار</option>
                        <option value="in_progress">قيد التنفيذ</option>
                        <option value="completed">مكتمل</option>
                        <option value="cancelled">ملغي</option>
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {repairs.length === 0 && (
          <div className="text-center py-12 text-slate-500">لا توجد طلبات صيانة</div>
        )}
      </div>
    </div>
  );
}
