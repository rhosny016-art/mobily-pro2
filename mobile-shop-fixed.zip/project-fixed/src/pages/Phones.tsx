import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Smartphone, ChevronLeft } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import ProductCard from '../components/ProductCard';
import { db } from '../lib/db';
import type { Product, Company } from '../types';

type PhoneType = 'new' | 'used';

export default function Phones() {
  const [phoneType, setPhoneType] = useState<PhoneType>('new');
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);

  useEffect(() => {
    setCompanies(db.companies.getByType('phone'));
  }, []);

  useEffect(() => {
    const category = phoneType === 'new' ? 'phone_new' : 'phone_used';
    let filtered = db.products.getByCategory(category);
    if (selectedCompany) {
      filtered = filtered.filter(p => p.company === selectedCompany);
    }
    setProducts(filtered);
  }, [phoneType, selectedCompany]);

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="الهواتف" subtitle="اختر ما يناسبك من الهواتف الجديدة والمستعملة" />

      {/* Phone Type Tabs */}
      <div className="flex justify-center gap-4 mb-8">
        <button
          onClick={() => { setPhoneType('new'); setSelectedCompany(null); }}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors ${
            phoneType === 'new'
              ? 'bg-emerald-500 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Smartphone className="w-5 h-5" />
          هواتف جديدة
        </button>
        <button
          onClick={() => { setPhoneType('used'); setSelectedCompany(null); }}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors ${
            phoneType === 'used'
              ? 'bg-emerald-500 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Smartphone className="w-5 h-5" />
          هواتف مستعملة
        </button>
      </div>

      {/* Companies */}
      <div className="mb-8">
        <div className="flex flex-wrap justify-center gap-2">
          <button
            onClick={() => setSelectedCompany(null)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              selectedCompany === null
                ? 'bg-slate-900 text-white'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            الكل
          </button>
          {companies.map((company) => (
            <button
              key={company.id}
              onClick={() => setSelectedCompany(company.name)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedCompany === company.name
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {company.name}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      {products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <Smartphone className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 text-lg">لا توجد منتجات في هذا القسم حالياً</p>
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium mt-4"
          >
            <ChevronLeft className="w-4 h-4" />
            العودة للرئيسية
          </Link>
        </div>
      )}
    </div>
  );
}
