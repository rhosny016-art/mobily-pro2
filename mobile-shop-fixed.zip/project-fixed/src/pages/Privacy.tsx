import { useEffect, useState } from 'react';
import SectionTitle from '../components/SectionTitle';
import { db } from '../lib/db';
import type { SiteSettings } from '../types';

export default function Privacy() {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    setSettings(db.settings.get());
  }, []);

  return (
    <div className="py-8 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="سياسة الخصوصية" />

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
        <div className="prose prose-slate max-w-none">
          <p className="text-slate-700 leading-relaxed whitespace-pre-line">
            {settings?.privacyText || `نحن نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية.

1. جمع المعلومات:
نقوم بجمع المعلومات التي تقدمها لنا طوعاً عند استخدامك لموقعنا، مثل اسمك ورقم هاتفك.

2. استخدام المعلومات:
نستخدم معلوماتك فقط للتواصل معك وتقديم خدماتنا لك.

3. حماية المعلومات:
نحن نتخذ إجراءات أمنية مناسبة لحماية معلوماتك من الوصول غير المصرح به.

4. مشاركة المعلومات:
لا نشارك معلوماتك الشخصية مع أي طرف ثالث.

5. التواصل:
قد نتواصل معك عبر واتساب أو الهاتف للرد على استفساراتك.`}
          </p>
        </div>
      </div>
    </div>
  );
}
