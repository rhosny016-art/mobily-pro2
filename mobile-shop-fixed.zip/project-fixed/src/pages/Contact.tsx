import { useEffect, useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageCircle } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import WhatsAppButton from '../components/WhatsAppButton';
import { db } from '../lib/db';
import type { SiteSettings } from '../types';

export default function Contact() {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    setSettings(db.settings.get());
  }, []);

  if (!settings) return null;

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="تواصل معنا" subtitle="نحن هنا لمساعدتك في أي وقت" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
          <h2 className="text-xl font-bold text-slate-900 mb-6">معلومات التواصل</h2>
          <div className="space-y-5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                <Phone className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm text-slate-500">رقم الهاتف / واتساب</p>
                <p className="font-semibold text-slate-900" dir="ltr">{settings.whatsappNumber}</p>
              </div>
            </div>

            {settings.email && (
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <Mail className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">البريد الإلكتروني</p>
                  <p className="font-semibold text-slate-900">{settings.email}</p>
                </div>
              </div>
            )}

            {settings.address && (
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">العنوان</p>
                  <p className="font-semibold text-slate-900">{settings.address}</p>
                </div>
              </div>
            )}

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm text-slate-500">مواعيد العمل</p>
                <p className="font-semibold text-slate-900">{settings.workingHours.saturday} - {settings.workingHours.friday}</p>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <WhatsAppButton
              phone={settings.whatsappNumber}
              message="مرحباً، أريد التواصل معكم"
              label="تواصل عبر واتساب"
              className="w-full justify-center"
            />
          </div>
        </div>

        <div className="bg-emerald-500 rounded-xl p-8 text-white flex flex-col justify-center items-center text-center">
          <MessageCircle className="w-16 h-16 mb-4 opacity-90" />
          <h2 className="text-2xl font-bold mb-2">هل تحتاج إلى مساعدة؟</h2>
          <p className="text-emerald-100 mb-6 max-w-md">
            فريقنا جاهز للإجابة على جميع استفساراتك. تواصل معنا عبر واتساب للحصول على استجابة سريعة.
          </p>
          <WhatsAppButton
            phone={settings.whatsappNumber}
            message="مرحباً، أريد المساعدة"
            label="تواصل الآن"
            className="bg-white text-emerald-600 hover:bg-emerald-50"
          />
        </div>
      </div>
    </div>
  );
}
