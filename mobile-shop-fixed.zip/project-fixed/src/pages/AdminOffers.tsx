import { useState, useEffect } from 'react';
import { Tag } from 'lucide-react';
import { db } from '../lib/db';
import type { Product } from '../types';

export default function AdminOffers() {
  const [offers, setOffers] = useState<Product[]>([]);

  const load = () => {
    const all = db.products.getAll();
    setOffers(all.filter(p => p.isOffer));
  };

  useEffect(() => { load(); }, []);

  const toggleOffer = (product: Product) => {
    db.products.update(product.id, { isOffer: !product.isOffer });
    load();
  };

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'phone_new': return 'هاتف جديد';
      case 'phone_used': return 'هاتف مستعمل';
      case 'accessory': return 'إكسسوار';
      default: return cat;
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-6">العروض</h1>
      <p className="text-slate-500 mb-4">المنتجات المميزة بعلامة "عرض" تظهر في قسم العروض</p>
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-right text-sm font-semibold">المنتج</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">النوع</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">الحالة</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {offers.map(product => (
              <tr key={product.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 flex items-center gap-3">
                  <img src={product.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover bg-slate-100" />
                  <span className="font-medium">{product.name}</span>
                </td>
                <td className="px-4 py-3 text-sm">{getCategoryLabel(product.category)}</td>
                <td className="px-4 py-3">
                  <span className="bg-red-100 text-red-600 text-xs px-2 py-0.5 rounded flex items-center gap-1 w-fit">
                    <Tag className="w-3 h-3" /> عرض
                  </span>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => toggleOffer(product)}
                    className="text-sm text-slate-600 hover:text-red-600 transition-colors"
                  >
                    إزالة من العروض
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {offers.length === 0 && (
          <div className="text-center py-12 text-slate-500">لا توجد عروض حالياً. أضف علامة "عرض" على المنتجات من قسم المنتجات.</div>
        )}
      </div>

      <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">جميع المنتجات</h2>
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-right text-sm font-semibold">المنتج</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">النوع</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">إضافة للعروض</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {db.products.getAll().filter(p => !p.isOffer).map(product => (
              <tr key={product.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 flex items-center gap-3">
                  <img src={product.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover bg-slate-100" />
                  <span className="font-medium">{product.name}</span>
                </td>
                <td className="px-4 py-3 text-sm">{getCategoryLabel(product.category)}</td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => toggleOffer(product)}
                    className="text-sm text-emerald-600 hover:text-emerald-700 transition-colors"
                  >
                    إضافة للعروض
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
