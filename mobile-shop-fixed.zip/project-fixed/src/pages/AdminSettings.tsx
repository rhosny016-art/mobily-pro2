import { useState, useEffect } from 'react';
import { Save, Phone, Mail, MapPin, Clock } from 'lucide-react';
import { db } from '../lib/db';
import type { SiteSettings } from '../types';

export default function AdminSettings() {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setSettings(db.settings.get());
  }, []);

  const handleChange = (field: string, value: any) => {
    if (!settings) return;
    setSettings({ ...settings, [field]: value });
  };

  const handleWorkingHours = (day: string, value: string) => {
    if (!settings) return;
    setSettings({
      ...settings,
      workingHours: { ...settings.workingHours, [day]: value },
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (settings) {
      db.settings.update(settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }
  };

  if (!settings) return null;

  const days = [
    { key: 'saturday', label: 'السبت' },
    { key: 'sunday', label: 'الأحد' },
    { key: 'monday', label: 'الإثنين' },
    { key: 'tuesday', label: 'الثلاثاء' },
    { key: 'wednesday', label: 'الأربعاء' },
    { key: 'thursday', label: 'الخميس' },
    { key: 'friday', label: 'الجمعة' },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-6">الإعدادات العامة</h1>
      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-6">
        {saved && (
          <div className="bg-emerald-50 text-emerald-700 px-4 py-3 rounded-lg flex items-center gap-2">
            <Save className="w-5 h-5" /> تم حفظ الإعدادات بنجاح
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">اسم الموقع</label>
            <input type="text" value={settings.siteName} onChange={e => handleChange('siteName', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">رقم واتساب</label>
            <div className="relative">
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" value={settings.whatsappNumber} onChange={e => handleChange('whatsappNumber', e.target.value)} className="w-full pr-10 px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">رقم الهاتف</label>
            <div className="relative">
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" value={settings.phoneNumber || ''} onChange={e => handleChange('phoneNumber', e.target.value)} className="w-full pr-10 px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">البريد الإلكتروني</label>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="email" value={settings.email || ''} onChange={e => handleChange('email', e.target.value)} className="w-full pr-10 px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">العنوان</label>
            <div className="relative">
              <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" value={settings.address || ''} onChange={e => handleChange('address', e.target.value)} className="w-full pr-10 px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">فيسبوك</label>
            <input type="text" value={settings.facebook || ''} onChange={e => handleChange('facebook', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" placeholder="https://facebook.com/..." />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">إنستغرام</label>
            <input type="text" value={settings.instagram || ''} onChange={e => handleChange('instagram', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" placeholder="https://instagram.com/..." />
          </div>
        </div>

        <div className="border-t border-slate-100 pt-6">
          <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-emerald-500" /> مواعيد العمل
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {days.map(day => (
              <div key={day.key}>
                <label className="block text-sm font-medium text-slate-700 mb-1">{day.label}</label>
                <input
                  type="text"
                  value={settings.workingHours[day.key as keyof typeof settings.workingHours] || ''}
                  onChange={e => handleWorkingHours(day.key, e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                  placeholder="مثال: 10:00 ص - 10:00 م"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-slate-100 pt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">نص "من نحن"</label>
            <textarea rows={4} value={settings.aboutText || ''} onChange={e => handleChange('aboutText', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none resize-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">نص سياسة الخصوصية</label>
            <textarea rows={4} value={settings.privacyText || ''} onChange={e => handleChange('privacyText', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none resize-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">نص الشروط والأحكام</label>
            <textarea rows={4} value={settings.termsText || ''} onChange={e => handleChange('termsText', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none resize-none" />
          </div>
        </div>

        <div className="flex justify-end">
          <button type="submit" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 py-2.5 rounded-lg transition-colors">
            <Save className="w-5 h-5" /> حفظ الإعدادات
          </button>
        </div>
      </form>
    </div>
  );
}
