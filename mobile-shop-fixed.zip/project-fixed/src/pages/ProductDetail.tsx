import { useParams, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { ArrowLeft, Battery, HardDrive, MemoryStick, Zap, MessageSquare, Tag, ChevronLeft, ChevronRight } from 'lucide-react';
import WhatsAppButton from '../components/WhatsAppButton';
import { db } from '../lib/db';
import type { Product } from '../types';

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    if (id) {
      const found = db.products.getById(id);
      setProduct(found || null);
      setCurrentImage(0);
    }
  }, [id]);

  if (!product) {
    return (
      <div className="py-16 text-center max-w-7xl mx-auto px-4">
        <p className="text-slate-500 text-lg">المنتج غير موجود</p>
        <Link to="/" className="text-emerald-600 hover:text-emerald-700 font-medium mt-4 inline-block">
          العودة للرئيسية
        </Link>
      </div>
    );
  }

  const getCategoryLabel = () => {
    switch (product.category) {
      case 'phone_new': return 'هاتف جديد';
      case 'phone_used': return 'هاتف مستعمل';
      case 'accessory': return 'إكسسوار';
      default: return '';
    }
  };

  const getConditionLabel = (condition?: string) => {
    switch (condition) {
      case 'excellent': return 'ممتازة';
      case 'very_good': return 'جيدة جداً';
      case 'good': return 'جيدة';
      default: return '';
    }
  };

  const whatsappMessage = `مرحباً، أريد الاستفسار عن: ${product.name}\nرابط المنتج: ${window.location.origin}/product/${product.id}`;

  const images = product.images.length > 0 ? product.images : ['https://via.placeholder.com/600'];

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <Link
        to="/"
        className="inline-flex items-center gap-1 text-slate-500 hover:text-slate-700 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        العودة
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Images */}
        <div>
          <div className="relative aspect-square bg-slate-100 rounded-xl overflow-hidden mb-4">
            <img
              src={images[currentImage]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.isOffer && (
              <div className="absolute top-4 right-4 bg-red-500 text-white text-sm font-bold px-3 py-1.5 rounded-full flex items-center gap-1">
                <Tag className="w-4 h-4" />
                عرض
              </div>
            )}
            {images.length > 1 && (
              <>
                <button
                  onClick={() => setCurrentImage((prev) => (prev - 1 + images.length) % images.length)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 hover:bg-white rounded-full flex items-center justify-center shadow-md"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setCurrentImage((prev) => (prev + 1) % images.length)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 hover:bg-white rounded-full flex items-center justify-center shadow-md"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
              </>
            )}
          </div>
          {images.length > 1 && (
            <div className="flex gap-2 justify-center">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentImage(idx)}
                  className={`w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                    idx === currentImage ? 'border-emerald-500' : 'border-transparent'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="bg-slate-900 text-white text-xs font-medium px-2.5 py-1 rounded">
              {getCategoryLabel()}
            </span>
            {product.company && (
              <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1 rounded">
                {product.company}
              </span>
            )}
          </div>

          <h1 className="text-3xl font-bold text-slate-900 mb-4">{product.name}</h1>
          <p className="text-slate-600 leading-relaxed mb-6">{product.description}</p>

          {/* Specifications */}
          <div className="bg-slate-50 rounded-xl p-6 mb-6">
            <h3 className="font-bold text-slate-900 mb-4">المواصفات</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {product.model && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <Zap className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">الموديل</p>
                    <p className="font-medium text-slate-900">{product.model}</p>
                  </div>
                </div>
              )}
              {product.ram && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <MemoryStick className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">الرام</p>
                    <p className="font-medium text-slate-900">{product.ram}</p>
                  </div>
                </div>
              )}
              {product.storage && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <HardDrive className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">المساحة</p>
                    <p className="font-medium text-slate-900">{product.storage}</p>
                  </div>
                </div>
              )}
              {product.batteryHealth !== undefined && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <Battery className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">صحة البطارية</p>
                    <p className="font-medium text-slate-900">{product.batteryHealth}%</p>
                  </div>
                </div>
              )}
              {product.condition && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <MessageSquare className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">الحالة</p>
                    <p className="font-medium text-slate-900">{getConditionLabel(product.condition)}</p>
                  </div>
                </div>
              )}
              {product.hasCharger !== undefined && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <Zap className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">الشاحن</p>
                    <p className="font-medium text-slate-900">{product.hasCharger ? 'نعم' : 'لا'}</p>
                  </div>
                </div>
              )}
              {product.accessoryType && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <Tag className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">الفئة</p>
                    <p className="font-medium text-slate-900">{product.accessoryType}</p>
                  </div>
                </div>
              )}
            </div>

            {product.conditionNotes && (
              <div className="mt-4 pt-4 border-t border-slate-200">
                <p className="text-xs text-slate-500 mb-1">ملاحظات الحالة</p>
                <p className="text-slate-700">{product.conditionNotes}</p>
              </div>
            )}
          </div>

          {/* WhatsApp CTA */}
          <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-6">
            <p className="text-emerald-800 font-medium mb-4">
              لا يتم عرض السعر مباشرة. تواصل معنا عبر واتساب للاستفسار عن السعر.
            </p>
            <WhatsAppButton
              phone="01031715424"
              message={whatsappMessage}
              label="اسأل عن السعر عبر واتساب"
              className="w-full justify-center text-lg py-3"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
