import { useState } from 'react';
import { Wrench, Upload, CheckCircle } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import { db } from '../lib/db';

export default function Repair() {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    deviceType: '',
    company: '',
    model: '',
    problemDescription: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Save to DB
    db.repairs.create(formData);

    // Open WhatsApp
    const message = `طلب صيانة جديد\n\nالاسم: ${formData.fullName}\nرقم الهاتف: ${formData.phone}\nنوع الجهاز: ${formData.deviceType}\nالشركة: ${formData.company}\nالموديل: ${formData.model}\nوصف العطل: ${formData.problemDescription}`;
    const url = `https://wa.me/201031715424?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');

    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <CheckCircle className="w-20 h-20 text-emerald-500 mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-slate-900 mb-2">تم إرسال طلبك بنجاح</h2>
        <p className="text-slate-500 mb-6">تم فتح واتساب مع رسالة تحتوي على تفاصيل طلبك</p>
        <button
          onClick={() => { setSubmitted(false); setFormData({ fullName: '', phone: '', deviceType: '', company: '', model: '', problemDescription: '' }); }}
          className="bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-6 py-2.5 rounded-lg transition-colors"
        >
          إرسال طلب جديد
        </button>
      </div>
    );
  }

  return (
    <div className="py-8 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="طلب صيانة" subtitle="املأ النموذج وسنقوم بالتواصل معك في أقرب وقت" />

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
            <Wrench className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <h2 className="font-bold text-slate-900">نموذج طلب الصيانة</h2>
            <p className="text-sm text-slate-500">جميع الحقول المطلوبة</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">الاسم الكامل *</label>
              <input
                type="text"
                name="fullName"
                required
                value={formData.fullName}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-colors"
                placeholder="أدخل اسمك الكامل"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">رقم الهاتف *</label>
              <input
                type="tel"
                name="phone"
                required
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-colors"
                placeholder="01xxxxxxxxx"
                dir="ltr"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">نوع الجهاز *</label>
              <select
                name="deviceType"
                required
                value={formData.deviceType}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-colors"
              >
                <option value="">اختر نوع الجهاز</option>
                <option value="هاتف ذكي">هاتف ذكي</option>
                <option value="تابلت">تابلت</option>
                <option value="ساعة ذكية">ساعة ذكية</option>
                <option value="سماعات">سماعات</option>
                <option value="أخرى">أخرى</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">الشركة *</label>
              <input
                type="text"
                name="company"
                required
                value={formData.company}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-colors"
                placeholder="مثال: Samsung, Apple"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">موديل الجهاز *</label>
            <input
              type="text"
              name="model"
              required
              value={formData.model}
              onChange={handleChange}
              className="w-full px-4 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-colors"
              placeholder="مثال: Galaxy S24, iPhone 15"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">وصف المشكلة *</label>
            <textarea
              name="problemDescription"
              required
              rows={4}
              value={formData.problemDescription}
              onChange={handleChange}
              className="w-full px-4 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-colors resize-none"
              placeholder="صف المشكلة التي تواجهك بالتفصيل..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">صورة للمشكلة (اختياري)</label>
            <div className="border-2 border-dashed border-slate-200 rounded-lg p-6 text-center hover:border-emerald-300 transition-colors cursor-pointer">
              <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-500">اضغط لرفع صورة أو اسحبها هنا</p>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold py-3 rounded-lg transition-colors"
          >
            إرسال الطلب
          </button>
        </form>
      </div>
    </div>
  );
}
