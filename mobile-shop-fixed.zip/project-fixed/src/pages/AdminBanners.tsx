import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Eye, EyeOff } from 'lucide-react';
import { db } from '../lib/db';
import type { Banner } from '../types';

export default function AdminBanners() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ title: '', subtitle: '', image: '', link: '', isActive: true, order: 1 });

  const load = () => setBanners(db.banners.getAll().sort((a, b) => a.order - b.order));
  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm({ title: '', subtitle: '', image: '', link: '', isActive: true, order: banners.length + 1 }); setEditingId(null); setShowModal(true); };
  const openEdit = (b: Banner) => { setForm({ title: b.title, subtitle: b.subtitle || '', image: b.image, link: b.link || '', isActive: b.isActive, order: b.order }); setEditingId(b.id); setShowModal(true); };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) db.banners.update(editingId, form);
    else db.banners.create(form);
    setShowModal(false); load();
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد؟')) { db.banners.delete(id); load(); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">البانرات</h1>
        <button onClick={openAdd} className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-4 py-2 rounded-lg transition-colors">
          <Plus className="w-5 h-5" /> إضافة بانر
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {banners.map(b => (
          <div key={b.id} className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="relative h-40 bg-slate-100">
              <img src={b.image} alt={b.title} className="w-full h-full object-cover" />
              <div className="absolute top-2 right-2 flex gap-1">
                {b.isActive ? <span className="bg-emerald-500 text-white text-xs px-2 py-0.5 rounded flex items-center gap-1"><Eye className="w-3 h-3"/> ظاهر</span> : <span className="bg-slate-500 text-white text-xs px-2 py-0.5 rounded flex items-center gap-1"><EyeOff className="w-3 h-3"/> مخفي</span>}
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-slate-900">{b.title}</h3>
              <p className="text-sm text-slate-500 mb-3">{b.subtitle}</p>
              <div className="flex gap-2">
                <button onClick={() => openEdit(b)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => handleDelete(b.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4"><h2 className="text-lg font-bold">{editingId ? 'تعديل' : 'إضافة'} بانر</h2><button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button></div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div><label className="block text-sm font-medium mb-1">العنوان</label><input type="text" required value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div><label className="block text-sm font-medium mb-1">العنوان الفرعي</label><input type="text" value={form.subtitle} onChange={e => setForm({...form, subtitle: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div><label className="block text-sm font-medium mb-1">رابط الصورة</label><input type="text" required value={form.image} onChange={e => setForm({...form, image: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div><label className="block text-sm font-medium mb-1">الرابط</label><input type="text" value={form.link} onChange={e => setForm({...form, link: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium mb-1">الترتيب</label><input type="number" value={form.order} onChange={e => setForm({...form, order: Number(e.target.value)})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
                <div className="flex items-center gap-2 pt-6"><input type="checkbox" checked={form.isActive} onChange={e => setForm({...form, isActive: e.target.checked})} className="w-4 h-4" /><span className="text-sm">نشط</span></div>
              </div>
              <div className="flex justify-end gap-3">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">إلغاء</button>
                <button type="submit" className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg">حفظ</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
