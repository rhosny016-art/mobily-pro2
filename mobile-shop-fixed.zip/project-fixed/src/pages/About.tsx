import { useEffect, useState } from 'react';
import { Shield, Award, Headphones, Truck } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import { db } from '../lib/db';
import type { SiteSettings } from '../types';

const features = [
  { icon: Shield, title: 'منتجات أصلية', desc: 'نضمن لك أصالة جميع منتجاتنا مع ضمان شامل' },
  { icon: Award, title: 'جودة عالية', desc: 'نختار منتجاتنا بعناية فائقة لتلبية توقعاتك' },
  { icon: Headphones, title: 'دعم فني', desc: 'فريق متخصص جاهز لمساعدتك في أي وقت' },
  { icon: Truck, title: 'خدمة سريعة', desc: 'سرعة في التوصيل والصيانة والاستجابة لطلباتك' },
];

export default function About() {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    setSettings(db.settings.get());
  }, []);

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="من نحن" subtitle="تعرف على موبايلي برو" />

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8 mb-12">
        <p className="text-lg text-slate-700 leading-relaxed text-center max-w-3xl mx-auto">
          {settings?.aboutText || 'موبايلي برو هو وجهتك الأولى لشراء الهواتف الجديدة والمستعملة وإكسسوارات الهواتف وخدمات الصيانة. نقدم منتجات أصلية بجودة عالية وأسعار تنافسية مع ضمان على جميع منتجاتنا.'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature) => {
          const Icon = feature.icon;
          return (
            <div key={feature.title} className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 text-center hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Icon className="w-7 h-7 text-emerald-600" />
              </div>
              <h3 className="font-bold text-slate-900 mb-2">{feature.title}</h3>
              <p className="text-sm text-slate-500">{feature.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
