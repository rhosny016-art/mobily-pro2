import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Shield, User, Lock } from 'lucide-react';
import { db } from '../lib/db';
import { changePassword } from '../lib/auth';
import type { AdminUser } from '../types';

export default function AdminUsers() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [passwordUserId, setPasswordUserId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', email: '', role: 'admin' as 'super_admin' | 'admin', password: '' });
  const [newPassword, setNewPassword] = useState('');
  const isSuperAdmin = db.auth.isSuperAdmin();

  const load = () => setUsers(db.users.getAll());
  useEffect(() => { load(); }, []);

  const openAdd = () => { 
    setForm({ name: '', email: '', role: 'admin', password: '' }); 
    setEditingId(null); 
    setShowModal(true); 
  };
  
  const openEdit = (u: AdminUser) => { 
    setForm({ name: u.name, email: u.email, role: u.role, password: '' }); 
    setEditingId(u.id); 
    setShowModal(true); 
  };

  const openPasswordChange = (u: AdminUser) => {
    setPasswordUserId(u.id);
    setNewPassword('');
    setShowPasswordModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      db.users.update(editingId, { name: form.name, email: form.email, role: form.role });
      if (form.password) {
        await changePassword(form.email, form.password);
      }
    } else {
      db.users.create({ name: form.name, email: form.email, role: form.role });
      if (form.password) {
        await changePassword(form.email, form.password);
      }
    }
    setShowModal(false); 
    load();
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordUserId) return;
    const user = db.users.getAll().find(u => u.id === passwordUserId);
    if (user) {
      await changePassword(user.email, newPassword);
      setShowPasswordModal(false);
      alert('تم تغيير كلمة المرور بنجاح');
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المستخدم؟')) { 
      db.users.delete(id); 
      load(); 
    }
  };

  if (!isSuperAdmin) {
    return (
      <div className="text-center py-16">
        <Shield className="w-16 h-16 text-slate-300 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-900 mb-2">غير مصرح</h2>
        <p className="text-slate-500">فقط المدير العام يمكنه إدارة المستخدمين</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">المستخدمين</h1>
        <button onClick={openAdd} className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-4 py-2 rounded-lg transition-colors">
          <Plus className="w-5 h-5" /> إضافة مستخدم
        </button>
      </div>
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-right text-sm font-semibold">الاسم</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">البريد</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">الدور</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map(u => (
              <tr key={u.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 flex items-center gap-2">
                  {u.role === 'super_admin' ? <Shield className="w-4 h-4 text-emerald-500" /> : <User className="w-4 h-4 text-slate-400" />}
                  <span className="font-medium">{u.name}</span>
                </td>
                <td className="px-4 py-3 text-sm text-slate-600" dir="ltr">{u.email}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs px-2 py-0.5 rounded ${u.role === 'super_admin' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                    {u.role === 'super_admin' ? 'مدير عام' : 'مدير'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(u)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => openPasswordChange(u)} className="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg"><Lock className="w-4 h-4" /></button>
                    {u.role !== 'super_admin' && (
                      <button onClick={() => handleDelete(u.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-4"><h2 className="text-lg font-bold">{editingId ? 'تعديل' : 'إضافة'} مستخدم</h2><button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button></div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div><label className="block text-sm font-medium mb-1">الاسم</label><input type="text" required value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div><label className="block text-sm font-medium mb-1">البريد الإلكتروني</label><input type="email" required value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" /></div>
              <div><label className="block text-sm font-medium mb-1">الدور</label><select value={form.role} onChange={e => setForm({...form, role: e.target.value as any})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"><option value="admin">مدير</option><option value="super_admin">مدير عام</option></select></div>
              <div><label className="block text-sm font-medium mb-1">{editingId ? 'كلمة مرور جديدة (اتركها فارغة للإبقاء على الحالية)' : 'كلمة المرور'}</label><input type="password" required={!editingId} value={form.password} onChange={e => setForm({...form, password: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" /></div>
              <div className="flex justify-end gap-3">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">إلغاء</button>
                <button type="submit" className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg">حفظ</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-4"><h2 className="text-lg font-bold">تغيير كلمة المرور</h2><button onClick={() => setShowPasswordModal(false)}><X className="w-5 h-5" /></button></div>
            <form onSubmit={handlePasswordChange} className="space-y-4">
              <div><label className="block text-sm font-medium mb-1">كلمة المرور الجديدة</label><input type="password" required minLength={6} value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" dir="ltr" /></div>
              <div className="flex justify-end gap-3">
                <button type="button" onClick={() => setShowPasswordModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">إلغاء</button>
                <button type="submit" className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg">تغيير</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
