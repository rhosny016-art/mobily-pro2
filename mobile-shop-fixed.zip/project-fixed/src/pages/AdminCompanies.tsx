import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Building2 } from 'lucide-react';
import { db } from '../lib/db';
import type { Company } from '../types';

export default function AdminCompanies() {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [type, setType] = useState<'phone' | 'accessory'>('phone');

  const load = () => setCompanies(db.companies.getAll());
  useEffect(() => { load(); }, []);

  const openAdd = () => { setName(''); setType('phone'); setEditingId(null); setShowModal(true); };
  const openEdit = (c: Company) => { setName(c.name); setType(c.type); setEditingId(c.id); setShowModal(true); };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) db.companies.update(editingId, { name, type });
    else db.companies.create({ name, type });
    setShowModal(false); load();
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد؟')) { db.companies.delete(id); load(); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">الشركات</h1>
        <button onClick={openAdd} className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-4 py-2 rounded-lg transition-colors">
          <Plus className="w-5 h-5" /> إضافة شركة
        </button>
      </div>
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50"><tr><th className="px-4 py-3 text-right text-sm font-semibold">الاسم</th><th className="px-4 py-3 text-right text-sm font-semibold">النوع</th><th className="px-4 py-3 text-right text-sm font-semibold">الإجراءات</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {companies.map(c => (
              <tr key={c.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 flex items-center gap-2"><Building2 className="w-4 h-4 text-slate-400" />{c.name}</td>
                <td className="px-4 py-3 text-sm">{c.type === 'phone' ? 'هاتف' : 'إكسسوار'}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(c)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(c.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-4"><h2 className="text-lg font-bold">{editingId ? 'تعديل' : 'إضافة'} شركة</h2><button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button></div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div><label className="block text-sm font-medium mb-1">الاسم</label><input type="text" required value={name} onChange={e => setName(e.target.value)} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div><label className="block text-sm font-medium mb-1">النوع</label><select value={type} onChange={e => setType(e.target.value as any)} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"><option value="phone">هاتف</option><option value="accessory">إكسسوار</option></select></div>
              <div className="flex justify-end gap-3">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">إلغاء</button>
                <button type="submit" className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg">حفظ</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
