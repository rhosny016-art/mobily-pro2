import { useEffect, useState } from 'react';
import SectionTitle from '../components/SectionTitle';
import { db } from '../lib/db';
import type { SiteSettings } from '../types';

export default function Terms() {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    setSettings(db.settings.get());
  }, []);

  return (
    <div className="py-8 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="الشروط والأحكام" />

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
        <div className="prose prose-slate max-w-none">
          <p className="text-slate-700 leading-relaxed whitespace-pre-line">
            {settings?.termsText || `باستخدامك لهذا الموقع، فإنك توافق على الشروط والأحكام التالية:

1. الاستخدام:
يجب استخدام الموقع لأغراض قانونية فقط.

2. المنتجات:
جميع المنتجات المعروضة خاضعة للتوفر. الأسعار قابلة للتغيير.

3. سياسة الإرجاع:
جميع المنتجات خاضعة لسياسة الإرجاع خلال 14 يوماً من تاريخ الشراء.

4. الصيانة:
خدمات الصيانة تخضع لتقييم الفني المختص.

5. المسؤولية:
نحن غير مسؤولين عن أي أضرار ناتجة عن الاستخدام غير الصحيح للمنتجات.

6. التعديلات:
نحتفظ بالحق في تعديل هذه الشروط في أي وقت.`}
          </p>
        </div>
      </div>
    </div>
  );
}
