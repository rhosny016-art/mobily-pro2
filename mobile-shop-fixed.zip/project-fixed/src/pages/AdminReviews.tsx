import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Star, Eye, EyeOff } from 'lucide-react';
import { db } from '../lib/db';
import type { Review } from '../types';

export default function AdminReviews() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', rating: 5, comment: '', isActive: true });

  const load = () => setReviews(db.reviews.getAll().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm({ name: '', rating: 5, comment: '', isActive: true }); setEditingId(null); setShowModal(true); };
  const openEdit = (r: Review) => { setForm({ name: r.name, rating: r.rating, comment: r.comment, isActive: r.isActive }); setEditingId(r.id); setShowModal(true); };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) db.reviews.update(editingId, form);
    else db.reviews.create(form);
    setShowModal(false); load();
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد؟')) { db.reviews.delete(id); load(); }
  };

  const toggleActive = (r: Review) => {
    db.reviews.update(r.id, { isActive: !r.isActive });
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">التقييمات</h1>
        <button onClick={openAdd} className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-4 py-2 rounded-lg transition-colors">
          <Plus className="w-5 h-5" /> إضافة تقييم
        </button>
      </div>
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-right text-sm font-semibold">العميل</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">التقييم</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">التعليق</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">الحالة</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {reviews.map(r => (
              <tr key={r.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium">{r.name}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`w-4 h-4 ${i < r.rating ? 'text-yellow-400 fill-yellow-400' : 'text-slate-300'}`} />
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-slate-600 max-w-xs truncate">{r.comment}</td>
                <td className="px-4 py-3">
                  <button onClick={() => toggleActive(r)} className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded transition-colors ${r.isActive ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>
                    {r.isActive ? <><Eye className="w-3 h-3" /> ظاهر</> : <><EyeOff className="w-3 h-3" /> مخفي</>}
                  </button>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(r)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(r.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {reviews.length === 0 && <div className="text-center py-12 text-slate-500">لا توجد تقييمات</div>}
      </div>
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-4"><h2 className="text-lg font-bold">{editingId ? 'تعديل' : 'إضافة'} تقييم</h2><button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button></div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div><label className="block text-sm font-medium mb-1">الاسم</label><input type="text" required value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div><label className="block text-sm font-medium mb-1">التقييم (1-5)</label><input type="number" min={1} max={5} required value={form.rating} onChange={e => setForm({...form, rating: Number(e.target.value)})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none" /></div>
              <div><label className="block text-sm font-medium mb-1">التعليق</label><textarea rows={3} required value={form.comment} onChange={e => setForm({...form, comment: e.target.value})} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none resize-none" /></div>
              <div className="flex items-center gap-2"><input type="checkbox" checked={form.isActive} onChange={e => setForm({...form, isActive: e.target.checked})} className="w-4 h-4" /><span className="text-sm">ظاهر</span></div>
              <div className="flex justify-end gap-3">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">إلغاء</button>
                <button type="submit" className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg">حفظ</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
