import { useEffect, useState } from 'react';
import { Package, Wrench, Star, Tag, TrendingUp } from 'lucide-react';
import { db } from '../lib/db';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    products: 0,
    repairs: 0,
    reviews: 0,
    offers: 0,
  });

  useEffect(() => {
    setStats({
      products: db.products.getAll().length,
      repairs: db.repairs.getAll().length,
      reviews: db.reviews.getAll().length,
      offers: db.products.getOffers().length,
    });
  }, []);

  const cards = [
    { label: 'إجمالي المنتجات', value: stats.products, icon: Package, color: 'bg-blue-500' },
    { label: 'طلبات الصيانة', value: stats.repairs, icon: Wrench, color: 'bg-orange-500' },
    { label: 'التقييمات', value: stats.reviews, icon: Star, color: 'bg-yellow-500' },
    { label: 'العروض', value: stats.offers, icon: Tag, color: 'bg-red-500' },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-6">لوحة التحكم</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-white rounded-xl p-6 shadow-sm border border-slate-100">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${card.color} rounded-xl flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <TrendingUp className="w-5 h-5 text-slate-300" />
              </div>
              <p className="text-2xl font-bold text-slate-900">{card.value}</p>
              <p className="text-sm text-slate-500">{card.label}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
        <h2 className="text-lg font-bold text-slate-900 mb-4">مرحباً بك في لوحة تحكم موبايلي برو</h2>
        <p className="text-slate-600 leading-relaxed">
          من هنا يمكنك إدارة جميع محتويات الموقع بما في ذلك المنتجات والفئات والشركات والبانرات والعروض وطلبات الصيانة والتقييمات والإعدادات العامة.
          استخدم القائمة الجانبية للتنقل بين الأقسام المختلفة.
        </p>
      </div>
    </div>
  );
}
