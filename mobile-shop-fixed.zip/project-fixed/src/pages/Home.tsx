import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Phone, Package, Wrench, Tag, ArrowLeft, Star, Clock, MapPin } from 'lucide-react';
import HeroBanner from '../components/HeroBanner';
import SectionTitle from '../components/SectionTitle';
import ProductCard from '../components/ProductCard';
import WhatsAppButton from '../components/WhatsAppButton';
import { db } from '../lib/db';
import type { Product, Review, SiteSettings } from '../types';

const sections = [
  { title: 'الهواتف', desc: 'جديدة ومستعملة', icon: Phone, path: '/phones', color: 'bg-blue-500' },
  { title: 'الإكسسوارات', desc: 'جميع الماركات', icon: Package, path: '/accessories', color: 'bg-purple-500' },
  { title: 'الصيانة', desc: 'فريق متخصص', icon: Wrench, path: '/repair', color: 'bg-orange-500' },
  { title: 'العروض', desc: 'خصومات حصرية', icon: Tag, path: '/offers', color: 'bg-red-500' },
];

export default function Home() {
  const [latestPhones, setLatestPhones] = useState<Product[]>([]);
  const [latestAccessories, setLatestAccessories] = useState<Product[]>([]);
  const [offers, setOffers] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    setLatestPhones(db.products.getLatest(4).filter(p => p.category.includes('phone')));
    setLatestAccessories(db.products.getLatest(4).filter(p => p.category === 'accessory'));
    setOffers(db.products.getOffers().slice(0, 4));
    setReviews(db.reviews.getActive());
    setSettings(db.settings.get());
  }, []);

  return (
    <div>
      <HeroBanner />

      {/* Sections Grid */}
      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Link
                key={section.path}
                to={section.path}
                className="group bg-white rounded-xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-all text-center"
              >
                <div className={`w-14 h-14 ${section.color} rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-bold text-slate-900 mb-1">{section.title}</h3>
                <p className="text-sm text-slate-500">{section.desc}</p>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Latest Phones */}
      {latestPhones.length > 0 && (
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <SectionTitle title="أحدث الهواتف" centered={false} />
              <Link to="/phones" className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium">
                عرض الكل
                <ArrowLeft className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {latestPhones.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Latest Accessories */}
      {latestAccessories.length > 0 && (
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <SectionTitle title="أحدث الإكسسوارات" centered={false} />
              <Link to="/accessories" className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium">
                عرض الكل
                <ArrowLeft className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {latestAccessories.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Offers */}
      {offers.length > 0 && (
        <section className="py-12 bg-emerald-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <SectionTitle title="عروض خاصة" subtitle="لا تفوت فرصتك" centered={false} />
              <Link to="/offers" className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium">
                عرض الكل
                <ArrowLeft className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {offers.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Reviews */}
      {reviews.length > 0 && (
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionTitle title="آراء العملاء" subtitle="ماذا يقول عملاؤنا عنا" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {reviews.map((review) => (
                <div key={review.id} className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                  <div className="flex items-center gap-1 mb-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-slate-300'}`}
                      />
                    ))}
                  </div>
                  <p className="text-slate-700 mb-4 leading-relaxed">{review.comment}</p>
                  <p className="font-semibold text-slate-900">{review.name}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Contact Info */}
      {settings && (
        <section className="py-12 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="w-14 h-14 bg-emerald-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-7 h-7 text-emerald-400" />
                </div>
                <h3 className="font-bold text-lg mb-2">اتصل بنا</h3>
                <p className="text-slate-400" dir="ltr">{settings.whatsappNumber}</p>
              </div>
              <div>
                <div className="w-14 h-14 bg-emerald-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-7 h-7 text-emerald-400" />
                </div>
                <h3 className="font-bold text-lg mb-2">العنوان</h3>
                <p className="text-slate-400">{settings.address || 'مصر'}</p>
              </div>
              <div>
                <div className="w-14 h-14 bg-emerald-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-7 h-7 text-emerald-400" />
                </div>
                <h3 className="font-bold text-lg mb-2">مواعيد العمل</h3>
                <p className="text-slate-400">{settings.workingHours.saturday || '10:00 ص - 10:00 م'}</p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* WhatsApp Floating Button */}
      <div className="fixed bottom-6 left-6 z-50">
        <WhatsAppButton
          phone="01031715424"
          message="مرحباً، أريد التواصل معكم"
          label=""
          className="w-14 h-14 rounded-full shadow-lg hover:scale-110 transition-transform justify-center p-0"
        />
      </div>
    </div>
  );
}
