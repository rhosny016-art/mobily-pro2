import { Link } from 'react-router-dom';
import { Tag, ChevronLeft } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import ProductCard from '../components/ProductCard';
import { db } from '../lib/db';

export default function Offers() {
  const offers = db.products.getOffers();

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <SectionTitle title="العروض الخاصة" subtitle="أفضل العروض والخصومات على منتجاتنا" />

      {offers.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {offers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <Tag className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 text-lg">لا توجد عروض حالياً</p>
          <p className="text-slate-400 text-sm mt-2">تابعنا قريباً للحصول على أحدث العروض</p>
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium mt-4"
          >
            <ChevronLeft className="w-4 h-4" />
            العودة للرئيسية
          </Link>
        </div>
      )}
    </div>
  );
}
