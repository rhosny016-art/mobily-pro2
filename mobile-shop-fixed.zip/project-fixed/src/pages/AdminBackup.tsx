import { useState } from 'react';
import { Download, Upload, Database, AlertTriangle, CheckCircle } from 'lucide-react';

const STORAGE_KEYS = [
  'mobily_pro_products',
  'mobily_pro_companies',
  'mobily_pro_categories',
  'mobily_pro_banners',
  'mobily_pro_repairs',
  'mobily_pro_reviews',
  'mobily_pro_settings',
  'mobily_pro_users',
  'mobily_pro_passwords',
];

export default function AdminBackup() {
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error'>('success');

  const showMessage = (msg: string, type: 'success' | 'error' = 'success') => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 5000);
  };

  const exportBackup = () => {
    const backup: Record<string, any> = {};
    let totalSize = 0;

    STORAGE_KEYS.forEach((key) => {
      const data = localStorage.getItem(key);
      if (data) {
        backup[key] = data;
        totalSize += data.length;
      }
    });

    const backupData = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      data: backup,
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mobily_pro_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    const sizeKB = (totalSize / 1024).toFixed(2);
    showMessage(`تم تصدير النسخة الاحتياطية بنجاح (${sizeKB} KB)`);
  };

  const importBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const backupData = JSON.parse(event.target?.result as string);

        if (!backupData.data || typeof backupData.data !== 'object') {
          showMessage('ملف النسخة الاحتياطية غير صالح', 'error');
          return;
        }

        if (!confirm('⚠️ سيتم استبدال جميع البيانات الحالية بالبيانات من الملف. هل أنت متأكد؟')) {
          return;
        }

        // Clear existing data
        STORAGE_KEYS.forEach((key) => {
          localStorage.removeItem(key);
        });

        // Restore data
        Object.entries(backupData.data).forEach(([key, value]) => {
          if (typeof value === 'string') {
            localStorage.setItem(key, value);
          }
        });

        showMessage('تم استعادة النسخة الاحتياطية بنجاح! سيتم تحديث الصفحة...');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } catch (err) {
        showMessage('حدث خطأ أثناء قراءة الملف', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const getDataStats = () => {
    const stats = STORAGE_KEYS.map((key) => {
      const data = localStorage.getItem(key);
      let count = 0;
      if (data) {
        try {
          const parsed = JSON.parse(data);
          count = Array.isArray(parsed) ? parsed.length : 1;
        } catch {
          count = 1;
        }
      }
      return { key, count, exists: !!data };
    });
    return stats;
  };

  const stats = getDataStats();

  const getKeyLabel = (key: string) => {
    const labels: Record<string, string> = {
      'mobily_pro_products': 'المنتجات',
      'mobily_pro_companies': 'الشركات',
      'mobily_pro_categories': 'الفئات',
      'mobily_pro_banners': 'البانرات',
      'mobily_pro_repairs': 'طلبات الصيانة',
      'mobily_pro_reviews': 'التقييمات',
      'mobily_pro_settings': 'الإعدادات',
      'mobily_pro_users': 'المستخدمين',
      'mobily_pro_passwords': 'كلمات المرور',
    };
    return labels[key] || key;
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-6">نسخ احتياطي واستعادة</h1>

      {message && (
        <div className={`mb-6 p-4 rounded-lg flex items-center gap-2 ${
          messageType === 'success' ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
        }`}>
          {messageType === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
          {message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Export */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
              <Download className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900">تصدير نسخة احتياطية</h2>
              <p className="text-sm text-slate-500">حفظ جميع بيانات الموقع في ملف JSON</p>
            </div>
          </div>
          <button
            onClick={exportBackup}
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold py-2.5 rounded-lg transition-colors"
          >
            تصدير البيانات
          </button>
        </div>

        {/* Import */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Upload className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900">استعادة نسخة احتياطية</h2>
              <p className="text-sm text-slate-500">استيراد البيانات من ملف JSON محفوظ</p>
            </div>
          </div>
          <label className="w-full block">
            <input
              type="file"
              accept=".json"
              onChange={importBackup}
              className="hidden"
            />
            <span className="w-full block text-center bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2.5 rounded-lg transition-colors cursor-pointer">
              استيراد البيانات
            </span>
          </label>
        </div>
      </div>

      {/* Data Stats */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
        <h2 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-emerald-500" />
          حالة قاعدة البيانات
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {stats.map((stat) => (
            <div
              key={stat.key}
              className={`flex items-center justify-between p-3 rounded-lg border ${
                stat.exists ? 'bg-emerald-50 border-emerald-100' : 'bg-slate-50 border-slate-100'
              }`}
            >
              <span className="text-sm font-medium text-slate-700">{getKeyLabel(stat.key)}</span>
              <span className={`text-sm font-bold ${stat.exists ? 'text-emerald-600' : 'text-slate-400'}`}>
                {stat.exists ? `${stat.count} عنصر` : 'فارغ'}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
        <div>
          <h3 className="font-semibold text-amber-800 text-sm">تنبيه مهم</h3>
          <p className="text-sm text-amber-700 mt-1">
            يُنصح بتصدير نسخة احتياطية بشكل دوري. عند استيراد نسخة احتياطية، سيتم استبدال جميع البيانات الحالية بالبيانات من الملف.
            لا يمكن التراجع عن عملية الاستيراد.
          </p>
        </div>
      </div>
    </div>
  );
}
