export interface Product {
  id: string;
  name: string;
  description: string;
  images: string[];
  category: 'phone_new' | 'phone_used' | 'accessory';
  company?: string;
  model?: string;
  ram?: string;
  storage?: string;
  batteryHealth?: number;
  condition?: 'excellent' | 'very_good' | 'good';
  hasCharger?: boolean;
  conditionNotes?: string;
  accessoryType?: string;
  isOffer: boolean;
  isHidden: boolean;
  createdAt: string;
}

export interface Company {
  id: string;
  name: string;
  logo?: string;
  type: 'phone' | 'accessory';
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  type: 'phone' | 'accessory';
  createdAt: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle?: string;
  image: string;
  link?: string;
  isActive: boolean;
  order: number;
}

export interface RepairRequest {
  id: string;
  fullName: string;
  phone: string;
  deviceType: string;
  company: string;
  model: string;
  problemDescription: string;
  image?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  image?: string;
  isActive: boolean;
  createdAt: string;
}

export interface SiteSettings {
  id: string;
  siteName: string;
  logo?: string;
  whatsappNumber: string;
  phoneNumber?: string;
  email?: string;
  address?: string;
  facebook?: string;
  instagram?: string;
  workingHours: {
    saturday?: string;
    sunday?: string;
    monday?: string;
    tuesday?: string;
    wednesday?: string;
    thursday?: string;
    friday?: string;
  };
  aboutText?: string;
  privacyText?: string;
  termsText?: string;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'super_admin' | 'admin';
  createdAt: string;
}

export type PhoneCondition = 'excellent' | 'very_good' | 'good';

export const PHONE_COMPANIES = [
  'Samsung', 'Apple', 'Xiaomi', 'Oppo', 'Realme',
  'Huawei', 'Vivo', 'Infinix', 'Tecno', 'Nokia'
];

export const ACCESSORY_CATEGORIES = [
  'سماعات', 'جرابات', 'اسكرينات حماية', 'شواحن',
  'كابلات', 'باور بانك', 'ساعات ذكية', 'حاملات هواتف'
];
