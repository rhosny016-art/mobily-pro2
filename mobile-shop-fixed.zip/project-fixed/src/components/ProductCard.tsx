import { Link } from 'react-router-dom';
import { Tag, Eye } from 'lucide-react';
import WhatsAppButton from './WhatsAppButton';
import type { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const getCategoryLabel = () => {
    switch (product.category) {
      case 'phone_new': return 'هاتف جديد';
      case 'phone_used': return 'هاتف مستعمل';
      case 'accessory': return 'إكسسوار';
      default: return '';
    }
  };

  const getConditionLabel = (condition?: string) => {
    switch (condition) {
      case 'excellent': return 'ممتازة';
      case 'very_good': return 'جيدة جداً';
      case 'good': return 'جيدة';
      default: return '';
    }
  };

  const whatsappMessage = `مرحباً، أريد الاستفسار عن: ${product.name}\nرابط المنتج: ${window.location.origin}/product/${product.id}`;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="relative aspect-square overflow-hidden bg-slate-50">
        <img
          src={product.images[0] || '/placeholder.jpg'}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        {product.isOffer && (
          <div className="absolute top-3 right-3 bg-red-500 text-white text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Tag className="w-3 h-3" />
            عرض
          </div>
        )}
        <div className="absolute top-3 left-3 bg-slate-900/70 text-white text-xs font-medium px-2.5 py-1 rounded-full">
          {getCategoryLabel()}
        </div>
      </div>

      <div className="p-4">
        <h3 className="font-bold text-slate-900 mb-1 line-clamp-1">{product.name}</h3>
        <p className="text-sm text-slate-500 mb-3 line-clamp-2">{product.description}</p>

        {product.category === 'phone_used' && (
          <div className="flex flex-wrap gap-1.5 mb-3">
            {product.ram && (
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{product.ram} رام</span>
            )}
            {product.storage && (
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{product.storage}</span>
            )}
            {product.batteryHealth && (
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded">بطارية {product.batteryHealth}%</span>
            )}
            {product.condition && (
              <span className="text-xs bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded">{getConditionLabel(product.condition)}</span>
            )}
          </div>
        )}

        {product.accessoryType && (
          <span className="inline-block text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded mb-3">
            {product.accessoryType}
          </span>
        )}

        <div className="flex items-center gap-2">
          <Link
            to={`/product/${product.id}`}
            className="flex-1 inline-flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium px-4 py-2 rounded-lg transition-colors text-sm"
          >
            <Eye className="w-4 h-4" />
            التفاصيل
          </Link>
          <WhatsAppButton
            phone="01031715424"
            message={whatsappMessage}
            label="استفسر"
            className="flex-1 text-sm py-2"
          />
        </div>
      </div>
    </div>
  );
}
