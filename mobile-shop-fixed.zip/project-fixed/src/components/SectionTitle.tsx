interface SectionTitleProps {
  title: string;
  subtitle?: string;
  centered?: boolean;
}

export default function SectionTitle({ title, subtitle, centered = true }: SectionTitleProps) {
  return (
    <div className={`mb-8 ${centered ? 'text-center' : ''}`}>
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">{title}</h2>
      {subtitle && <p className="text-slate-500">{subtitle}</p>}
      <div className={`h-1 w-16 bg-emerald-500 rounded-full mt-3 ${centered ? 'mx-auto' : ''}`} />
    </div>
  );
}
