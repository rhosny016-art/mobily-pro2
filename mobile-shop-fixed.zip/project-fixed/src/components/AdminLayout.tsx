import { useEffect, useState } from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Package, Tag, Wrench, Star, Settings,
  Users, Image, LogOut, Menu, X, Building2, Layers, ChevronLeft,
  Database
} from 'lucide-react';
import { db } from '../lib/db';
import type { AdminUser } from '../types';

const navItems = [
  { path: '/admin', label: 'الرئيسية', icon: LayoutDashboard },
  { path: '/admin/products', label: 'المنتجات', icon: Package },
  { path: '/admin/companies', label: 'الشركات', icon: Building2 },
  { path: '/admin/categories', label: 'الفئات', icon: Layers },
  { path: '/admin/banners', label: 'البانرات', icon: Image },
  { path: '/admin/offers', label: 'العروض', icon: Tag },
  { path: '/admin/repairs', label: 'طلبات الصيانة', icon: Wrench },
  { path: '/admin/reviews', label: 'التقييمات', icon: Star },
  { path: '/admin/settings', label: 'الإعدادات', icon: Settings },
  { path: '/admin/backup', label: 'نسخ احتياطي', icon: Database },
  { path: '/admin/users', label: 'المستخدمين', icon: Users },
];

export default function AdminLayout() {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const currentUser = db.auth.getCurrentUser();
    if (!currentUser) {
      navigate('/admin-login');
      return;
    }
    setUser(currentUser);
  }, [navigate]);

  const handleLogout = () => {
    db.auth.logout();
    navigate('/admin-login');
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-100 flex" dir="rtl">
      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 right-0 z-40 h-screen w-64 bg-slate-900 text-white transition-transform lg:translate-x-0 ${
          isSidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <LayoutDashboard className="w-5 h-5" />
            </div>
            <span className="font-bold">لوحة التحكم</span>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="p-3 space-y-1 overflow-y-auto h-[calc(100vh-140px)]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsSidebarOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-0 right-0 left-0 p-3 border-t border-slate-800">
          <div className="px-3 py-2 mb-2">
            <p className="text-sm font-medium">{user.name}</p>
            <p className="text-xs text-slate-400">{user.role === 'super_admin' ? 'مدير عام' : 'مدير'}</p>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 min-w-0">
        <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between sticky top-0 z-20">
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="lg:hidden p-2 hover:bg-slate-100 rounded-lg"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Link to="/" className="hover:text-emerald-600 transition-colors">الموقع</Link>
            <ChevronLeft className="w-4 h-4" />
            <span>لوحة التحكم</span>
          </div>
        </header>
        <main className="p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
