import { MessageCircle } from 'lucide-react';

interface WhatsAppButtonProps {
  phone?: string;
  message?: string;
  label?: string;
  className?: string;
}

export default function WhatsAppButton({
  phone = '01031715424',
  message = 'مرحباً، أريد الاستفسار عن منتج',
  label = 'تواصل عبر واتساب',
  className = '',
}: WhatsAppButtonProps) {
  const handleClick = () => {
    const encodedMessage = encodeURIComponent(message);
    const url = `https://wa.me/${phone.replace(/^0/, '20')}?text=${encodedMessage}`;
    window.open(url, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className={`inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-5 py-2.5 rounded-lg transition-colors ${className}`}
    >
      <MessageCircle className="w-5 h-5" />
      {label}
    </button>
  );
}
